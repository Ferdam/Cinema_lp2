/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.lp2.cinema.controller;

import com.br.lp2.cinema.model.javabeans.Usuario;
import java.util.ArrayList;

/**
 *
 * @author Leticia
 */
/**
 *
 * @author Leticia
 */
public class Autenticador {

    private Usuario uComp;
    private ArrayList<Usuario> listausuarios = new ArrayList<>();
    private Usuario u1 = new Usuario("ger", "ger", "gerente");
    private Usuario u2 = new Usuario("func", "func", "funcionario");
    private Usuario u3 = new Usuario("leticia", "123", "funcionario");

    public Autenticador(Usuario u) {
        this.uComp = u;
    }

    public boolean autentica() {
        listausuarios.add(u1);
        listausuarios.add(u2);
        listausuarios.add(u3);

        boolean validado = false;

        for (Usuario user : listausuarios) {
            if (uComp.getNome().equals(user.getNome())
             && uComp.getSenha().equals(user.getSenha())) {

                validado = true;
                break;

            }
        }

        return validado;
    }

    public String auth() {
        listausuarios.add(u1);
        listausuarios.add(u2);
        listausuarios.add(u3);
        
        String papel = null;
        
        for (Usuario user : listausuarios) {
            if (uComp.getNome().equals(user.getNome())
             && uComp.getSenha().equals(user.getSenha())) {

                papel = user.getPapel();
                break;

            }
        }
        return papel;
    }

}
